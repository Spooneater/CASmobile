package com.example.attendancechecker;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class pickDevice extends AppCompatActivity {
    //devices_data[i] : i - id студента в рамках таблицы(1..n); [0]-адрес устройства (string); [1]-название (String);[2] : привязано ли уже это устройство(Boolean)

    Object[][] devices_data;
    //TODO Сделать заполнение данных
    protected void fillDevicesData(){

        //Magic data
        int n=3;
        devices_data = new Object[n][3];
        devices_data[0]= new Object[]{"11:22:33:44:55:66", "I am first device and used", true};
        devices_data[1]= new Object[]{"11:22:33:44:55:66", "I am second device and not used", false};
        devices_data[2]= new Object[]{"123213123321", "I am third", true};


    };
    private TextView errorMessageDevice;
    private int device_id;

    protected LinearLayout makeTableInst(int id, String name, String adress, Integer width){

        LinearLayout line = new LinearLayout(this);

        TextView id_text = new TextView(this);
        id_text.setText(Integer.toString(id+1));
        id_text.setGravity(Gravity.CENTER);
        id_text.setWidth(width / 6);
        id_text.setHeight(width / 6);
        id_text.setBackground(AppCompatResources.getDrawable(this,R.drawable.scrol_border));
        line.addView(id_text);
        LinearLayout twoRows = new LinearLayout(this);
        twoRows.setOrientation(LinearLayout.VERTICAL);
        //Название девайса
        TextView name_text = new TextView(this);
        name_text.setText(name);
        name_text.setPadding(15,0,0,0);
        name_text.setHeight(width / 6);

        name_text.setGravity(Gravity.CENTER_VERTICAL);
        name_text.setBackground(AppCompatResources.getDrawable(this,R.drawable.scrol_border));
        twoRows.addView(name_text);
        //Адрес
        TextView adress_text = new TextView(this);
        adress_text.setText(adress);
        adress_text.setPadding(15,0,0,0);
        adress_text.setHeight(width / 6);

        adress_text.setGravity(Gravity.CENTER_VERTICAL);
        adress_text.setBackground(AppCompatResources.getDrawable(this,R.drawable.scrol_border));
        twoRows.addView(adress_text);
        line.addView(twoRows);
        View overlay_view = new View(this);
        overlay_view.setAlpha((float)0.6);
        overlay_view.setBackgroundColor(getColor(R.color.black));
        line.addView(overlay_view);
        overlay_view.setVisibility(View.INVISIBLE);
        line.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                device_id = id;
                overlay_view.setVisibility(View.VISIBLE);
            }
        });
        return line;
    }
    //TODO
    protected boolean isConnected(){
        return true;
    }
    //TODO Собственно запрос. return true if получилось
    private boolean requestWiring()
    {
        return true;
    }
    //TODO 0-все норм. 1- нет инета. 2-устройство уже привязано. 3-UNKNOWN ERROR
    protected void tryToWire(){
        if (!isConnected()){
            errorMessageDevice.setText("Привязывать устройства можно только при подключении к сети");
            return;
        }
        if ((boolean)devices_data[device_id][2]){
            errorMessageDevice.setText("Этот адрес уже привязан к другому студенту");
            return;
        }
        //Попытка привязки. индекс в devices_data лежит в device_id подефолту -1
        if (requestWiring()){
            finish();
            return;
        }
        errorMessageDevice.setText("UNKNOWN ERROR");
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_device);
        errorMessageDevice = findViewById(R.id.errorMessageDevice);
        Button confirmBtn = findViewById(R.id.confirmDeviceBtn);
        device_id = -1;
        confirmBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tryToWire();
            }
        });
        LinearLayout tableLayoutStud = findViewById(R.id.tableLayoutDevice);
        fillDevicesData();
        tableLayoutStud.post(new Runnable() {
            @Override
            public void run() {
                Integer i =0;
                for (Object[] inst : devices_data) {
                    tableLayoutStud.addView(makeTableInst(i, (String)inst[1],(String)inst[0], tableLayoutStud.getWidth()));
                    i = i + 1;
                } ;
            }
        });
    }
}